#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:25/04/2024
#*****

#La funcion saludo() muestra en pantalla un saludo
def saludo():
    print("Hola ficha 2877795! :)")

#La funcion sum(dato1, dato2) suma 2 datos almacenados
def sum(dato1, dato2):
        #return devuelve el numero del resultado de la suma de dato1 + dato2
        return dato1 + dato2

#La funcion restar(dato1, dato2) resta 2 datos almacenados
def restar(dato1, dato2):
        #return devuelve el numero del resultado de la resta de dato1 - dato2  
        return dato1 - dato2

#La funcion multiplicar(dato1, dato2) multiplica 2 datos almacenados
def multiplicar(dato1, dato2):
        #return devuelve el numero del resultado de la multiplicacion de dato1 * dato2
        return dato1 * dato2

#La funcion dividir(dato1, dato2) divide 2 datos almacenados
def dividir(dato1, dato2):
    # El condicional if permite verificar si el divisor es cero
    if dato2 == 0:
    #return cumple la funcion de indicar que no se puede dividir por cero
        return "No se puede dividir por 0"
    #else permite realizar la division en caso de que el divisor sea un numero diferente de cero
    else:
        #return devuelve el numero del resultado de la division de dato1 / dato2
        return dato1 / dato2

#El condicional if permite llama la funcion para que en caso de que la funcion sea propia se ejecute y en caso de ser importada no se ejecute 
if __name__ == " __main__":
        saludo()
        #La funcion print(*Inicio*) muestra en pantalla *Inicio*
        print("*Inicio*")

#La funcion from importa los datos necesarios de la libreria para generar numeros aleatorios al momento de ingresar los datos para realizar las operaciones
from random import randint

dato1=randint(0,100)
dato2=randint(0,100)

#La funcion print("La suma es: ", sum(1dato1, dato2)) muestra en pantalla el resultado de la suma de dato1 + dato2
print(f"La suma de {dato1} y {dato2} es {sum(dato1, dato2)}")

#La funcion print("La resta es: ", restar(dato1, dato2)) muestra en pantalla el resultado de la resta de dato1 - dato2
print(f"La resta de {dato1} y {dato2} es {restar(dato1, dato2)}")

#La funcion print("La multiplicacion es: ", multiplicar(dato1, dato2)) muestra en pantalla el resultado de la multiplicacion de dato1 * dato2
print(f"La multiplicacion de {dato1} y {dato2} es {multiplicar(dato1, dato2)}")

#La funcion print("La division es: ", dividir(dato1, dato2)) muestra en pantalla el resultado de la division de dato1 / dato2
print(f"La division de {dato1} y {dato2} es {dividir(dato1, dato2)}")

#La funcion print(*Fin*) muestra en pantalla *Fin*
print("*Fin*")